--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = key_board, pg_catalog;

ALTER TABLE key_board.keys ALTER COLUMN id DROP DEFAULT;
ALTER TABLE key_board.keyrings ALTER COLUMN id DROP DEFAULT;
DROP VIEW key_board.keys_keyring_id_rel_mapping;
DROP SEQUENCE key_board.keys_id_seq;
DROP TABLE key_board.keys;
DROP SEQUENCE key_board.keyrings_id_seq;
DROP TABLE key_board.keyrings;
DROP SCHEMA key_board;
--
-- Name: key_board; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA key_board;


ALTER SCHEMA key_board OWNER TO postgres;

SET search_path = key_board, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: keyrings; Type: TABLE; Schema: key_board; Owner: postgres; Tablespace: 
--

CREATE TABLE keyrings (
    id integer NOT NULL,
    hardware_id character varying(180) NOT NULL,
    name character varying(120),
    is_plugged_in boolean DEFAULT false NOT NULL,
    critical_key boolean DEFAULT false NOT NULL
);


ALTER TABLE key_board.keyrings OWNER TO postgres;

--
-- Name: keyrings_id_seq; Type: SEQUENCE; Schema: key_board; Owner: postgres
--

CREATE SEQUENCE keyrings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE key_board.keyrings_id_seq OWNER TO postgres;

--
-- Name: keyrings_id_seq; Type: SEQUENCE OWNED BY; Schema: key_board; Owner: postgres
--

ALTER SEQUENCE keyrings_id_seq OWNED BY keyrings.id;


--
-- Name: keys; Type: TABLE; Schema: key_board; Owner: postgres; Tablespace: 
--

CREATE TABLE keys (
    id integer NOT NULL,
    keyring_id integer,
    name character varying(120)
);


ALTER TABLE key_board.keys OWNER TO postgres;

--
-- Name: keys_id_seq; Type: SEQUENCE; Schema: key_board; Owner: postgres
--

CREATE SEQUENCE keys_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE key_board.keys_id_seq OWNER TO postgres;

--
-- Name: keys_id_seq; Type: SEQUENCE OWNED BY; Schema: key_board; Owner: postgres
--

ALTER SEQUENCE keys_id_seq OWNED BY keys.id;


--
-- Name: keys_keyring_id_rel_mapping; Type: VIEW; Schema: key_board; Owner: postgres
--

CREATE VIEW keys_keyring_id_rel_mapping AS
    SELECT keyrings.id, keyrings.id AS value, keyrings.name AS label FROM keyrings;


ALTER TABLE key_board.keys_keyring_id_rel_mapping OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: key_board; Owner: postgres
--

ALTER TABLE ONLY keyrings ALTER COLUMN id SET DEFAULT nextval('keyrings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: key_board; Owner: postgres
--

ALTER TABLE ONLY keys ALTER COLUMN id SET DEFAULT nextval('keys_id_seq'::regclass);


--
-- Data for Name: keyrings; Type: TABLE DATA; Schema: key_board; Owner: postgres
--

COPY keyrings (id, hardware_id, name, is_plugged_in, critical_key) FROM stdin;
\.
COPY keyrings (id, hardware_id, name, is_plugged_in, critical_key) FROM '$$PATH$$/2026.dat';

--
-- Name: keyrings_id_seq; Type: SEQUENCE SET; Schema: key_board; Owner: postgres
--

SELECT pg_catalog.setval('keyrings_id_seq', 17, true);


--
-- Data for Name: keys; Type: TABLE DATA; Schema: key_board; Owner: postgres
--

COPY keys (id, keyring_id, name) FROM stdin;
\.
COPY keys (id, keyring_id, name) FROM '$$PATH$$/2028.dat';

--
-- Name: keys_id_seq; Type: SEQUENCE SET; Schema: key_board; Owner: postgres
--

SELECT pg_catalog.setval('keys_id_seq', 1, true);


--
-- PostgreSQL database dump complete
--

