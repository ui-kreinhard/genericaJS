--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.translations DROP CONSTRAINT translations_language_id_fkey;
ALTER TABLE ONLY public.user_language DROP CONSTRAINT fk_languages;
DROP TRIGGER table_translation_edit_view ON public.table_translation_edit_view;
DROP TRIGGER language_dml_trig ON public.languages_view;
DROP TRIGGER current_language_dml_trig ON public.current_language;
DROP INDEX public.fki_languages;
ALTER TABLE ONLY public.worktimes DROP CONSTRAINT worktimes_pkey;
ALTER TABLE ONLY public.worktimes DROP CONSTRAINT worktimes_date_start_date_end_key;
ALTER TABLE ONLY public.user_language DROP CONSTRAINT user_language_pkey;
ALTER TABLE ONLY public.translations DROP CONSTRAINT translations_pkey;
ALTER TABLE ONLY public.menu DROP CONSTRAINT pk_menu;
ALTER TABLE ONLY public.formelements_order DROP CONSTRAINT pk_formelements_order;
ALTER TABLE ONLY public.languages DROP CONSTRAINT languages_pkey;
ALTER TABLE public.worktimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.w1 ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_language ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.menu ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formerrors_translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formelements_order ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.worktimes_id_seq;
DROP VIEW public.w_;
DROP TABLE public.worktimes;
DROP SEQUENCE public.w1_id_seq;
DROP TABLE public.w1;
DROP VIEW public.view_menu;
DROP VIEW public.v4;
DROP VIEW public.v3;
DROP VIEW public.v2;
DROP VIEW public.v1;
DROP SEQUENCE public.user_language_id_seq;
DROP SEQUENCE public.translations_id_seq;
DROP VIEW public.table_translation_edit_view;
DROP VIEW public.schema_and_translation;
DROP VIEW public.menu_view;
DROP VIEW public.table_rights;
DROP VIEW public.menu_table_name_rel_mapping;
DROP VIEW public.tables_with_schema;
DROP VIEW public.menu_priviligue_rel_mapping;
DROP VIEW public.menu_menu_idmenu_rel_mapping;
DROP SEQUENCE public.menu_id2_seq;
DROP VIEW public.languages_view;
DROP SEQUENCE public.languages_id_seq;
DROP SEQUENCE public.formerrors_translations_id_seq;
DROP SEQUENCE public.formelements_order_id_seq;
DROP VIEW public.formelements_order_edit_view;
DROP VIEW public.formelement_orders_and_translation;
DROP TABLE public.translations;
DROP TABLE public.formelements_order;
DROP VIEW public.formelement_edit_tables;
DROP VIEW public.dummy_rel;
DROP VIEW public.customization_elementorder;
DROP VIEW public.tables;
DROP VIEW public.check_constraints;
DROP VIEW public.resolve_view_hierarchy;
DROP VIEW public.formerrors_translations_language;
DROP TABLE public.formerrors_translations;
DROP VIEW public.current_language;
DROP TABLE public.user_language;
DROP TABLE public.languages;
DROP TABLE public.menu;
DROP FUNCTION public.update_worktimes_fast();
DROP FUNCTION public.update_worktimes();
DROP FUNCTION public.update_tableactions();
DROP FUNCTION public.update_table_translation_edit_view();
DROP FUNCTION public.update_language_view();
DROP FUNCTION public.update_language();
DROP FUNCTION public.update_einkaufszettel_todo();
DROP FUNCTION public.unknown2text(unknown);
DROP FUNCTION public.totalrecords();
DROP FUNCTION public.remove_keyring(p_hardware_id character varying);
DROP FUNCTION public.rel_mapping_readout(schema_name character varying, tablename regclass);
DROP FUNCTION public.rel_mapping_readout(tablename regclass);
DROP FUNCTION public.process_audit();
DROP FUNCTION public.h_int(text);
DROP FUNCTION public.h_bigint(text);
DROP FUNCTION public.checkin_checkout_time();
DROP FUNCTION public.check_out_trigger();
DROP FUNCTION public.add_keyring(p_hardware_id character varying);
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET search_path = public, pg_catalog;

--
-- Name: add_keyring(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION add_keyring(p_hardware_id character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
	
	update key_board.keyrings kr
	set is_plugged_in=true
	where exists (
	  select 1
	  from key_board.keyrings krInner
	  where hardware_id = p_hardware_id and krInner.id = kr.id
	);
	insert into key_board.keyrings 
	(hardware_id, is_plugged_in)
	select p_hardware_id, TRUE
	where  not exists (
	  select 1
	  from key_board.keyrings krInner
	  where hardware_id = p_hardware_id
	);
	return 'u';
END
$$;


ALTER FUNCTION public.add_keyring(p_hardware_id character varying) OWNER TO postgres;

--
-- Name: check_out_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION check_out_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
	totalCheckIns integer;
	timeOfCheckIn timestamp;
   BEGIN
	select count(*) into totalCheckIns from checkin_checkout where user = current_user;
	if totalCheckIns <= 0 THEN
		INSERT INTO checkin_checkout("user", time_of_checkin) VALUES(CURRENT_USER,CURRENT_TIMESTAMP);
		return NEW;
	ELSE 
		select time_of_checkin into timeOfCheckIn from checkin_checkout where user = current_user;
		delete from checkin_checkout where user = current_user;
		INSERT INTO worktimes (date_start, date_end, description) values(timeOfCheckIn, current_timestamp, NEW.description);
		return NEW;
	END IF;
    END;
$$;


ALTER FUNCTION public.check_out_trigger() OWNER TO postgres;

--
-- Name: checkin_checkout_time(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION checkin_checkout_time() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
	totalCheckIns integer;
	timeOfCheckIn timestamp;
BEGIN
	select count(*) into totalCheckIns from checkin_checkout where user = current_user;
	if totalCheckIns <= 0 THEN
		INSERT INTO checkin_checkout("user", time_of_checkin) VALUES(CURRENT_USER,CURRENT_TIMESTAMP);
		return 'Checked In';
	ELSE 
		select time_of_checkin into timeOfCheckIn from checkin_checkout where user = current_user;
		delete from checkin_checkout where user = current_user;
		INSERT INTO worktimes (date_start, date_end) values(timeOfCheckIn, current_timestamp);
		return 'Checked out';
	END IF;
	END;
$$;


ALTER FUNCTION public.checkin_checkout_time() OWNER TO postgres;

--
-- Name: h_bigint(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION h_bigint(text) RETURNS bigint
    LANGUAGE sql
    AS $_$
 select ('x'||substr(md5($1),1,16))::bit(64)::bigint;
$_$;


ALTER FUNCTION public.h_bigint(text) OWNER TO postgres;

--
-- Name: h_int(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION h_int(text) RETURNS integer
    LANGUAGE sql
    AS $_$
 select ('x'||substr(md5($1),1,8))::bit(32)::int;
$_$;


ALTER FUNCTION public.h_int(text) OWNER TO postgres;

--
-- Name: process_audit(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION process_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
    BEGIN
        --
        -- Create a row in emp_audit to reflect the operation performed on emp,
        -- make use of the special variable TG_OP to work out the operation.
        --
        IF (TG_OP = 'DELETE') THEN
            EXECUTE format('INSERT INTO %I SELECT  CURRENT_TIMESTAMP,''D'', ($1).*', TG_TABLE_NAME || '_archive')
            USING OLD;
RETURN OLD;
        ELSIF (TG_OP = 'UPDATE') THEN
             EXECUTE format('INSERT INTO %I SELECT  CURRENT_TIMESTAMP,''U'', ($1).*', TG_TABLE_NAME || '_archive')
             USING OLD;
            RETURN NEW;
        ELSIF (TG_OP = 'INSERT') THEN
	
            RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$_$;


ALTER FUNCTION public.process_audit() OWNER TO postgres;

--
-- Name: rel_mapping_readout(regclass); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rel_mapping_readout(tablename regclass) RETURNS TABLE(id text, value text, label text)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY EXECUTE format('SELECT id::text, value::text, label::text FROM %s ', tableName);
END
$$;


ALTER FUNCTION public.rel_mapping_readout(tablename regclass) OWNER TO postgres;

--
-- Name: rel_mapping_readout(character varying, regclass); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rel_mapping_readout(schema_name character varying, tablename regclass) RETURNS TABLE(id integer, value integer, label character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY EXECUTE format('SELECT id, value, label FROM %s ', tableName);
END
$$;


ALTER FUNCTION public.rel_mapping_readout(schema_name character varying, tablename regclass) OWNER TO postgres;

--
-- Name: remove_keyring(character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION remove_keyring(p_hardware_id character varying) RETURNS character varying
    LANGUAGE plpgsql
    AS $$
BEGIN
	
	update key_board.keyrings kr
	set is_plugged_in=false
	where exists (
	  select 1
	  from key_board.keyrings krInner
	  where hardware_id = p_hardware_id and krInner.id = kr.id
	);
	insert into key_board.keyrings 
	(hardware_id, is_plugged_in)
	select p_hardware_id, false
	where  not exists (
	  select 1
	  from key_board.keyrings krInner
	  where hardware_id = p_hardware_id
	);
	return 'u';
END
$$;


ALTER FUNCTION public.remove_keyring(p_hardware_id character varying) OWNER TO postgres;

--
-- Name: totalrecords(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION totalrecords() RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	total integer;
BEGIN
   SELECT count(*) into total FROM COMPANY;
   RETURN total;
END;
$$;


ALTER FUNCTION public.totalrecords() OWNER TO postgres;

--
-- Name: unknown2text(unknown); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION unknown2text(unknown) RETURNS text
    LANGUAGE plpgsql
    AS $_$ begin return text($1::char); end $_$;


ALTER FUNCTION public.unknown2text(unknown) OWNER TO postgres;

--
-- Name: update_einkaufszettel_todo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_einkaufszettel_todo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
 IF TG_OP = 'INSERT' THEN
       
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
    
       RETURN NEW;
	ELSIF TG_OP = 'DELETE' THEN
	update einkaufszettel set eingekauft = true where id=OLD.id;
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_einkaufszettel_todo() OWNER TO postgres;

--
-- Name: update_language(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_language() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' OR  TG_OP = 'UPDATE' THEN
	update user_language ul set language_id = 
		(select id from languages l where l.language_name = NEW.language_name)
	where ul.username = current_user;
        insert into user_language (username, language_id)
	select current_user, (select id from languages l where l.language_name = NEW.language_name)	
        where NOT EXISTS(
		select 1 from user_language where username = current_user
        );
        RETURN NEW;
    
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_language() OWNER TO postgres;

--
-- Name: update_language_view(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_language_view() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
	insert into languages(language_name) values 
	(NEW.language_name);
        RETURN NEW;
	elseif TG_OP = 'UPDATE' THEN
	update languages set language_name = NEW.language_name where id = NEW.language_id;
	elseif TG_OP = 'DELETE' THEN
	delete from languages where id=NEW.language_id;
	RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_language_view() OWNER TO postgres;

--
-- Name: update_table_translation_edit_view(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_table_translation_edit_view() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
       update translations tr set translation = NEW.translation
	where tr.table_name = NEW.table_name and tr.column_name = NEW.column_name and tr.schema_name = NEW.table_schema;

	
	INSERT INTO translations 
	      (table_name,column_name, translation, language_id, schema_name) 
	select
	 table_name,column_name, NEW.translation, l.id, feo.table_schema 
	 from formelements_order_edit_view feo
	inner join current_language cr ON 1=1
	inner join languages l ON cr.language_name = l.language_name
	where NOT EXISTS(
		select 1 from translations trInner 
		inner join languages l ON l.id= trInner.language_id AND l.language_name = (select language_name from current_language)
		where 1=1
		and feo.table_name = trinner.table_name and feo.column_name = trinner.column_name and feo.table_schema = trinner.schema_name
	)
	and feo.table_name = NEW.table_name and  feo.column_name = NEW.column_name and  feo.table_schema = NEW.table_schema	;

       RETURN NEW;
      ELSIF TG_OP = 'DELETE' THEN
       
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_table_translation_edit_view() OWNER TO postgres;

--
-- Name: update_tableactions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_tableactions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        --
        -- Create a row in emp_audit to reflect the operation performed on emp,
        -- make use of the special variable TG_OP to work out the operation.
        --
        IF (TG_OP = 'DELETE') THEN
            delete from table_actions_inner where id = OLD.id;
	    RETURN OLD;
        ELSIF (TG_OP = 'UPDATE') THEN
	    delete from table_actions_inner where id = OLD.id;
	    insert into table_actions_inner select NEW.*;
            RETURN NEW;
        ELSIF (TG_OP = 'INSERT') THEN
        
	    insert into table_actions_inner (
            link, table_name, label_action, is_action)
		VALUES (new.link, new.table_name, new.label_action, new.is_action);
            RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;


ALTER FUNCTION public.update_tableactions() OWNER TO postgres;

--
-- Name: update_worktimes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_worktimes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        INSERT INTO worktimes (date_start, date_end)  VALUES(NEW.date_start,NEW.date_end);
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
       UPDATE worktimes SET date_start=NEW.date_start, date_end=NEW.date_end 
       WHERE id=OLD.id;
       RETURN NEW;
      ELSIF TG_OP = 'DELETE' THEN
       DELETE FROM worktimes WHERE id=OLD.id;
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_worktimes() OWNER TO postgres;

--
-- Name: update_worktimes_fast(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_worktimes_fast() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        INSERT INTO worktimes_persist (date_start, date_end)  VALUES(NEW.date_start,NEW.date_end);
        RETURN NEW;
        END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_worktimes_fast() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE menu (
    link character varying(120),
    menulabel character varying(45),
    menu_idmenu integer,
    id integer NOT NULL,
    table_name character varying(1024),
    priviligue character varying(255)
);


ALTER TABLE public.menu OWNER TO postgres;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE languages (
    id integer NOT NULL,
    language_name character varying NOT NULL
);


ALTER TABLE public.languages OWNER TO postgres;

--
-- Name: user_language; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_language (
    id integer NOT NULL,
    language_id integer NOT NULL,
    username character varying NOT NULL
);


ALTER TABLE public.user_language OWNER TO postgres;

--
-- Name: current_language; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW current_language AS
    SELECT languages.language_name FROM (user_language JOIN languages ON ((languages.id = user_language.language_id))) WHERE ((user_language.username)::name = "current_user"()) UNION SELECT 'english'::character varying AS language_name FROM pg_user pgu WHERE ((NOT (EXISTS (SELECT 1 FROM user_language ul WHERE (pgu.usename = (ul.username)::name)))) AND (pgu.usename = "current_user"()));


ALTER TABLE public.current_language OWNER TO postgres;

--
-- Name: formerrors_translations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE formerrors_translations (
    id integer NOT NULL,
    check_constraints_id bigint NOT NULL,
    error_msg character varying(1024) NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE public.formerrors_translations OWNER TO postgres;

--
-- Name: formerrors_translations_language; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formerrors_translations_language AS
    SELECT fet.id, fet.check_constraints_id, fet.error_msg, fet.language_id FROM ((formerrors_translations fet JOIN languages l ON ((l.id = fet.language_id))) JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (fet.language_id = l.id))));


ALTER TABLE public.formerrors_translations_language OWNER TO postgres;

--
-- Name: resolve_view_hierarchy; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW resolve_view_hierarchy AS
    WITH RECURSIVE resolve_view_hierarchy(view_name, table_name) AS (SELECT view_table_usage.view_name, view_table_usage.table_name, view_table_usage.view_schema FROM information_schema.view_table_usage UNION ALL SELECT parent.view_name, sub_view.table_name, sub_view.view_schema FROM information_schema.view_table_usage sub_view, information_schema.view_table_usage parent WHERE ((sub_view.view_name)::text = (parent.table_name)::text)) SELECT resolve_view_hierarchy.view_name, resolve_view_hierarchy.table_name, resolve_view_hierarchy.view_schema FROM resolve_view_hierarchy;


ALTER TABLE public.resolve_view_hierarchy OWNER TO postgres;

--
-- Name: check_constraints; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW check_constraints AS
    SELECT c.data_type, cc.id, CASE ((c.table_schema)::text = 'public'::text) WHEN true THEN (c.table_name)::text ELSE (((c.table_schema)::text || '.'::text) || (c.table_name)::text) END AS table_name, c.column_name, cc.check_clause, COALESCE(fetl.error_msg, (((cc.column_name)::text || ' is wrong'::text))::character varying) AS error_msg FROM (((SELECT h_bigint((((rvc.view_name)::text || (tc.column_name)::text) || (cc_1.check_clause)::text)) AS id, rvc.view_name AS table_name, tc.column_name, cc_1.check_clause, rvc.view_schema FROM ((resolve_view_hierarchy rvc JOIN information_schema.constraint_column_usage tc ON (((tc.table_name)::text = (rvc.table_name)::text))) JOIN information_schema.check_constraints cc_1 ON ((((cc_1.constraint_name)::text = (tc.constraint_name)::text) AND (NOT (EXISTS (SELECT 1 FROM information_schema.views v WHERE ((v.table_name)::text = (rvc.table_name)::text))))))) UNION ALL SELECT h_bigint((((cu.table_name)::text || (cu.column_name)::text) || (cc_1.check_clause)::text)) AS id, cu.table_name, cu.column_name, cc_1.check_clause, cu.table_schema AS view_schema FROM (information_schema.constraint_column_usage cu JOIN information_schema.check_constraints cc_1 ON (((cc_1.constraint_name)::text = (cu.constraint_name)::text)))) cc RIGHT JOIN information_schema.columns c ON ((((cc.table_name)::text = (c.table_name)::text) AND ((cc.column_name)::text = (c.column_name)::text)))) LEFT JOIN formerrors_translations_language fetl ON ((fetl.check_constraints_id = cc.id))) UNION ALL SELECT 'text'::character varying AS data_type, aa.id, aa.table_name, aa.column_name, aa.check_clause, COALESCE(fetl.error_msg, (((aa.column_name)::text || ' is not unique'::text))::character varying) AS error_msg FROM ((SELECT h_bigint((((rvc.view_name)::text || (tc.constraint_name)::text) || string_agg((kcu.column_name)::text, ','::text))) AS id, rvc.view_name AS table_name, tc.constraint_name AS column_name, ((((' not exists (select 1 from '::text || (rvc.view_name)::text) || ' already_existing_data where '::text) || string_agg(((('already_existing_data.'::text || (kcu.column_name)::text) || ' = to_check.'::text) || (kcu.column_name)::text), ' and '::text)) || ' and coalesce(to_check.id,-1) <> already_existing_data.id)'::text) AS check_clause FROM ((resolve_view_hierarchy rvc JOIN information_schema.table_constraints tc ON (((rvc.table_name)::text = (tc.table_name)::text))) LEFT JOIN information_schema.key_column_usage kcu ON (((((tc.constraint_catalog)::text = (kcu.constraint_catalog)::text) AND ((tc.constraint_schema)::text = (kcu.constraint_schema)::text)) AND ((tc.constraint_name)::text = (kcu.constraint_name)::text)))) WHERE ((tc.constraint_type)::text = ANY ((ARRAY['UNIQUE'::character varying, 'Primary Key'::character varying])::text[])) GROUP BY kcu.table_name, rvc.view_name, tc.constraint_name UNION ALL SELECT h_bigint((((tc.table_name)::text || (tc.constraint_name)::text) || string_agg((kcu.column_name)::text, ','::text))) AS id, tc.table_name, tc.constraint_name AS column_name, ((((' not exists (select 1 from '::text || (tc.table_name)::text) || ' already_existing_data where '::text) || string_agg(((('already_existing_data.'::text || (kcu.column_name)::text) || ' = to_check.'::text) || (kcu.column_name)::text), ' and '::text)) || ' and coalesce(to_check.id,-1) <> already_existing_data.id)'::text) AS check_clause FROM (information_schema.table_constraints tc LEFT JOIN information_schema.key_column_usage kcu ON (((((tc.constraint_catalog)::text = (kcu.constraint_catalog)::text) AND ((tc.constraint_schema)::text = (kcu.constraint_schema)::text)) AND ((tc.constraint_name)::text = (kcu.constraint_name)::text)))) WHERE ((tc.constraint_type)::text = ANY ((ARRAY['UNIQUE'::character varying, 'Primary Key'::character varying])::text[])) GROUP BY kcu.table_name, tc.table_name, tc.constraint_name) aa LEFT JOIN formerrors_translations_language fetl ON ((fetl.check_constraints_id = aa.id)));


ALTER TABLE public.check_constraints OWNER TO postgres;

--
-- Name: tables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW tables AS
    SELECT tables.table_catalog, tables.table_name, tables.table_schema FROM information_schema.tables WHERE ((tables.table_catalog)::name = current_database());


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: customization_elementorder; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW customization_elementorder AS
    SELECT tables.table_name AS id FROM tables UNION SELECT '1'::character varying AS id;


ALTER TABLE public.customization_elementorder OWNER TO postgres;

--
-- Name: dummy_rel; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW dummy_rel AS
    SELECT 1 AS id, 1 AS value, 'dummy'::character varying AS label WHERE (1 <> 1);


ALTER TABLE public.dummy_rel OWNER TO postgres;

--
-- Name: formelement_edit_tables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelement_edit_tables AS
    SELECT (((t.table_schema)::text || '.'::text) || (t.table_name)::text) AS id FROM information_schema.tables t WHERE ((t.table_schema)::text <> ALL (ARRAY[('information_schema'::character varying)::text, ('pg_catalog'::character varying)::text]));


ALTER TABLE public.formelement_edit_tables OWNER TO postgres;

--
-- Name: formelements_order; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE formelements_order (
    id integer NOT NULL,
    column_name character varying(65),
    table_name character varying(65),
    schema_name character varying(65)
);


ALTER TABLE public.formelements_order OWNER TO postgres;

--
-- Name: translations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE translations (
    id integer NOT NULL,
    table_name character(65) NOT NULL,
    column_name character varying NOT NULL,
    translation character varying NOT NULL,
    language_id integer NOT NULL,
    schema_name character varying(65) NOT NULL
);


ALTER TABLE public.translations OWNER TO postgres;

--
-- Name: formelement_orders_and_translation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelement_orders_and_translation AS
    SELECT feo.id, feo.column_name, feo.table_name, COALESCE(t.translation, feo.column_name) AS translation, feo.schema_name FROM (formelements_order feo LEFT JOIN translations t ON (((((feo.table_name)::bpchar = t.table_name) AND ((feo.column_name)::text = (t.column_name)::text)) AND (EXISTS (SELECT 1 FROM (languages l JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (t.language_id = l.id)))))))));


ALTER TABLE public.formelement_orders_and_translation OWNER TO postgres;

--
-- Name: formelements_order_edit_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelements_order_edit_view AS
    SELECT (((c.table_schema)::text || '.'::text) || (c.table_name)::text) AS id, c.column_name, c.table_name, c.table_schema FROM (information_schema.columns c LEFT JOIN formelements_order feo ON (((((c.table_name)::text = (feo.table_name)::text) AND ((feo.column_name)::text = (c.column_name)::text)) AND ((c.table_catalog)::name = current_database())))) WHERE ((c.table_schema)::text <> ALL (ARRAY[('information_schema'::character varying)::text, ('pg_catalog'::character varying)::text])) ORDER BY feo.id, c.table_name;


ALTER TABLE public.formelements_order_edit_view OWNER TO postgres;

--
-- Name: formelements_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formelements_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formelements_order_id_seq OWNER TO postgres;

--
-- Name: formelements_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formelements_order_id_seq OWNED BY formelements_order.id;


--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formerrors_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formerrors_translations_id_seq OWNER TO postgres;

--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formerrors_translations_id_seq OWNED BY formerrors_translations.id;


--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.languages_id_seq OWNER TO postgres;

--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE languages_id_seq OWNED BY languages.id;


--
-- Name: languages_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW languages_view AS
    SELECT languages.id, languages.language_name FROM languages;


ALTER TABLE public.languages_view OWNER TO postgres;

--
-- Name: menu_id2_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE menu_id2_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_id2_seq OWNER TO postgres;

--
-- Name: menu_id2_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE menu_id2_seq OWNED BY menu.id;


--
-- Name: menu_menu_idmenu_rel_mapping; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW menu_menu_idmenu_rel_mapping AS
    SELECT menu.id, menu.id AS value, menu.menulabel AS label FROM menu UNION SELECT 1 AS id, 1 AS value, 'abc'::character varying AS label;


ALTER TABLE public.menu_menu_idmenu_rel_mapping OWNER TO postgres;

--
-- Name: menu_priviligue_rel_mapping; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW menu_priviligue_rel_mapping AS
    ((SELECT 'SELECT'::text AS id, 'SELECT'::text AS value, 'SELECT'::text AS label UNION SELECT 'INSERT'::text AS id, 'INSERT'::text AS value, 'INSERT'::text AS label) UNION SELECT 'UPDATE'::text AS id, 'UPDATE'::text AS value, 'UPDATE'::text AS label) UNION SELECT 'DELETE'::text AS id, 'DELETE'::text AS value, 'DELETE'::text AS label;


ALTER TABLE public.menu_priviligue_rel_mapping OWNER TO postgres;

--
-- Name: tables_with_schema; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW tables_with_schema AS
    SELECT tables.table_catalog, tables.table_schema, tables.table_name, (((tables.table_schema)::text || '.'::text) || (tables.table_name)::text) AS full_name FROM information_schema.tables ORDER BY (((tables.table_schema)::text || '.'::text) || (tables.table_name)::text);


ALTER TABLE public.tables_with_schema OWNER TO postgres;

--
-- Name: menu_table_name_rel_mapping; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW menu_table_name_rel_mapping AS
    SELECT tables_with_schema.full_name AS id, tables_with_schema.full_name AS value, tables_with_schema.full_name AS label FROM tables_with_schema;


ALTER TABLE public.menu_table_name_rel_mapping OWNER TO postgres;

--
-- Name: table_rights; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW table_rights AS
    WITH table_rights_without_customize AS (SELECT CASE (pg_namespace.nspname = 'public'::name) WHEN true THEN (pg_class.relname)::text ELSE (((pg_namespace.nspname)::text || '.'::text) || (pg_class.relname)::text) END AS table_name, (((pg_namespace.nspname)::text || '.'::text) || (pg_class.relname)::text) AS full_name, CASE pg_class.relkind WHEN 'r'::"char" THEN 'TABLE'::text WHEN 'v'::"char" THEN 'VIEW'::text ELSE NULL::text END AS relation_type, privs.priv FROM (pg_class JOIN pg_namespace ON ((pg_namespace.oid = pg_class.relnamespace))), pg_user, (VALUES ('SELECT'::text,1), ('INSERT'::text,2), ('UPDATE'::text,3), ('DELETE'::text,4)) privs(priv, privorder) WHERE ((((pg_class.relkind = ANY (ARRAY['r'::"char", 'v'::"char"])) AND has_table_privilege(pg_user.usesysid, pg_class.oid, privs.priv)) AND (NOT ((pg_namespace.nspname ~ '^pg_'::text) OR (pg_namespace.nspname = 'information_schema'::name)))) AND (pg_user.usename = "current_user"()))) SELECT table_rights_without_customize.table_name, table_rights_without_customize.full_name, table_rights_without_customize.relation_type, table_rights_without_customize.priv, ((SELECT count(*) AS count FROM table_rights_without_customize WHERE ((table_rights_without_customize.table_name = 'formelements_order'::text) AND (table_rights_without_customize.priv = ANY (ARRAY['INSERT'::text, 'UPDATE'::text])))) > 0) AS can_customize FROM table_rights_without_customize;


ALTER TABLE public.table_rights OWNER TO postgres;

--
-- Name: menu_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW menu_view AS
    SELECT m.link, m.menulabel, m.menu_idmenu, m.id, m.table_name, m.priviligue FROM (menu m JOIN table_rights tr ON (((upper((m.table_name)::text) = upper(tr.full_name)) AND (upper((m.priviligue)::text) = upper(tr.priv)))));


ALTER TABLE public.menu_view OWNER TO postgres;

--
-- Name: schema_and_translation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW schema_and_translation AS
    SELECT CASE ((c.table_schema)::text = 'public'::text) WHEN true THEN (c.table_name)::text ELSE (((c.table_schema)::text || '.'::text) || (c.table_name)::text) END AS table_name, c.column_name AS field, c.character_maximum_length AS textlength, COALESCE(((SELECT c.data_type WHERE (mappings.table_name IS NULL)))::character varying, 'combobox'::character varying) AS data_type, (SELECT string_agg(rel_mapping_readout.value, ','::text) AS string_agg FROM rel_mapping_readout((COALESCE((((mappings.table_schema)::text || '.'::text) || (mappings.table_name)::text), ('dummy_rel'::character varying)::text))::regclass) rel_mapping_readout(id, value, label)) AS valuescombobox, (SELECT string_agg(rel_mapping_readout.label, ','::text) AS string_agg FROM rel_mapping_readout((COALESCE((((mappings.table_schema)::text || '.'::text) || (mappings.table_name)::text), ('dummy_rel'::character varying)::text))::regclass) rel_mapping_readout(id, value, label)) AS labels, COALESCE(trl.translation, (c.column_name)::character varying) AS "displayName", true AS visible FROM ((((tables t JOIN information_schema.columns c ON (((((t.table_name)::text = (c.table_name)::text) AND ((c.table_catalog)::name = current_database())) AND ((c.table_schema)::text = (t.table_schema)::text)))) LEFT JOIN formelements_order feo ON (((((feo.table_name)::text = (t.table_name)::text) AND ((feo.column_name)::text = (c.column_name)::text)) AND ((c.table_schema)::text = (feo.schema_name)::text)))) LEFT JOIN tables mappings ON ((((mappings.table_name)::text = ((((t.table_name)::text || '_'::text) || (c.column_name)::text) || '_rel_mapping'::text)) AND ((c.table_schema)::text = (mappings.table_schema)::text)))) LEFT JOIN translations trl ON ((((trl.table_name = (t.table_name)::bpchar) AND ((trl.column_name)::text = (c.column_name)::text)) AND (EXISTS (SELECT 1 FROM user_language WHERE (((user_language.username)::name = "current_user"()) AND (trl.language_id = user_language.language_id))))))) ORDER BY t.table_name, feo.id;


ALTER TABLE public.schema_and_translation OWNER TO postgres;

--
-- Name: table_translation_edit_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW table_translation_edit_view AS
    SELECT ((feo.id || '.'::text) || (feo.column_name)::text) AS id, feo.table_schema, feo.table_name, feo.column_name, t.language_id, COALESCE(t.translation, (feo.column_name)::character varying) AS translation FROM (formelements_order_edit_view feo LEFT JOIN translations t ON (((((feo.table_name)::bpchar = t.table_name) AND ((feo.column_name)::text = (t.column_name)::text)) AND (EXISTS (SELECT 1 FROM (languages l JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (t.language_id = l.id)))))))));


ALTER TABLE public.table_translation_edit_view OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.translations_id_seq OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE translations_id_seq OWNED BY translations.id;


--
-- Name: user_language_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_language_id_seq OWNER TO postgres;

--
-- Name: user_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_language_id_seq OWNED BY user_language.id;


--
-- Name: v1; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW v1 AS
    SELECT 1;


ALTER TABLE public.v1 OWNER TO postgres;

--
-- Name: v2; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW v2 AS
    SELECT v1."?column?" FROM v1;


ALTER TABLE public.v2 OWNER TO postgres;

--
-- Name: v3; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW v3 AS
    SELECT v2."?column?" FROM v2;


ALTER TABLE public.v3 OWNER TO postgres;

--
-- Name: v4; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW v4 AS
    SELECT 1 FROM v3, v2;


ALTER TABLE public.v4 OWNER TO postgres;

--
-- Name: view_menu; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW view_menu AS
    SELECT aa.link, aa.id, aa.menulabel, aa.menu_idmenu, aa.table_name, aa.priviligue FROM (SELECT ''::text AS link, t.table_name AS id, t.table_name AS menulabel, NULL::character varying AS menu_idmenu, 'information_schema.view_table_usage'::text AS table_name, 'SELECT'::text AS priviligue FROM information_schema.tables t WHERE (NOT (EXISTS (SELECT 1 FROM information_schema.view_table_usage vt WHERE ((vt.table_name)::text = (t.table_name)::text)))) UNION ALL SELECT ''::text AS link, vt.table_name AS id, vt.table_name AS menulabel, vt.view_name AS menu_idmenu, 'information_schema.view_table_usage'::text AS table_name, 'SELECT'::text AS priviligue FROM information_schema.view_table_usage vt) aa ORDER BY aa.id;


ALTER TABLE public.view_menu OWNER TO postgres;

--
-- Name: w1; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE w1 (
    id integer NOT NULL,
    date_start timestamp with time zone NOT NULL,
    date_end timestamp with time zone NOT NULL,
    aaaa date
);


ALTER TABLE public.w1 OWNER TO postgres;

--
-- Name: w1_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE w1_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.w1_id_seq OWNER TO postgres;

--
-- Name: w1_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE w1_id_seq OWNED BY w1.id;


--
-- Name: worktimes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE worktimes (
    id integer NOT NULL,
    "user" character varying(65) DEFAULT "current_user"() NOT NULL,
    date_start timestamp without time zone NOT NULL,
    date_end timestamp without time zone NOT NULL,
    description character varying DEFAULT ''::character varying NOT NULL,
    CONSTRAINT worktimes_check CHECK ((date_end > date_start))
);


ALTER TABLE public.worktimes OWNER TO postgres;

--
-- Name: w_; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW w_ AS
    SELECT worktimes.id, worktimes."user", worktimes.date_start, worktimes.date_end, worktimes.description FROM worktimes;


ALTER TABLE public.w_ OWNER TO postgres;

--
-- Name: worktimes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE worktimes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.worktimes_id_seq OWNER TO postgres;

--
-- Name: worktimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE worktimes_id_seq OWNED BY worktimes.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formelements_order ALTER COLUMN id SET DEFAULT (nextval('formelements_order_id_seq'::regclass) + 1);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formerrors_translations ALTER COLUMN id SET DEFAULT nextval('formerrors_translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY languages ALTER COLUMN id SET DEFAULT nextval('languages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY menu ALTER COLUMN id SET DEFAULT (nextval('menu_id2_seq'::regclass) + 17);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY translations ALTER COLUMN id SET DEFAULT nextval('translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_language ALTER COLUMN id SET DEFAULT nextval('user_language_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY w1 ALTER COLUMN id SET DEFAULT nextval('w1_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY worktimes ALTER COLUMN id SET DEFAULT nextval('worktimes_id_seq'::regclass);


--
-- Data for Name: formelements_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formelements_order (id, column_name, table_name, schema_name) FROM stdin;
\.
COPY formelements_order (id, column_name, table_name, schema_name) FROM '$$PATH$$/2136.dat';

--
-- Name: formelements_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formelements_order_id_seq', 184, true);


--
-- Data for Name: formerrors_translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formerrors_translations (id, check_constraints_id, error_msg, language_id) FROM stdin;
\.
COPY formerrors_translations (id, check_constraints_id, error_msg, language_id) FROM '$$PATH$$/2135.dat';

--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formerrors_translations_id_seq', 2, true);


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY languages (id, language_name) FROM stdin;
\.
COPY languages (id, language_name) FROM '$$PATH$$/2133.dat';

--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('languages_id_seq', 4, true);


--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY menu (link, menulabel, menu_idmenu, id, table_name, priviligue) FROM stdin;
\.
COPY menu (link, menulabel, menu_idmenu, id, table_name, priviligue) FROM '$$PATH$$/2141.dat';

--
-- Name: menu_id2_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('menu_id2_seq', 39, true);


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY translations (id, table_name, column_name, translation, language_id, schema_name) FROM stdin;
\.
COPY translations (id, table_name, column_name, translation, language_id, schema_name) FROM '$$PATH$$/2137.dat';

--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('translations_id_seq', 9184, true);


--
-- Data for Name: user_language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_language (id, language_id, username) FROM stdin;
\.
COPY user_language (id, language_id, username) FROM '$$PATH$$/2134.dat';

--
-- Name: user_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_language_id_seq', 6, true);


--
-- Data for Name: w1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY w1 (id, date_start, date_end, aaaa) FROM stdin;
\.
COPY w1 (id, date_start, date_end, aaaa) FROM '$$PATH$$/2148.dat';

--
-- Name: w1_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('w1_id_seq', 3, true);


--
-- Data for Name: worktimes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY worktimes (id, "user", date_start, date_end, description) FROM stdin;
\.
COPY worktimes (id, "user", date_start, date_end, description) FROM '$$PATH$$/2145.dat';

--
-- Name: worktimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('worktimes_id_seq', 4220234, true);


--
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: pk_formelements_order; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY formelements_order
    ADD CONSTRAINT pk_formelements_order PRIMARY KEY (id);


--
-- Name: pk_menu; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT pk_menu PRIMARY KEY (id);


--
-- Name: translations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (id);


--
-- Name: user_language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_language
    ADD CONSTRAINT user_language_pkey PRIMARY KEY (id);


--
-- Name: worktimes_date_start_date_end_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY worktimes
    ADD CONSTRAINT worktimes_date_start_date_end_key UNIQUE (date_start, date_end);


--
-- Name: worktimes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY worktimes
    ADD CONSTRAINT worktimes_pkey PRIMARY KEY (id);


--
-- Name: fki_languages; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_languages ON user_language USING btree (language_id);


--
-- Name: current_language_dml_trig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER current_language_dml_trig INSTEAD OF INSERT OR DELETE OR UPDATE ON current_language FOR EACH ROW EXECUTE PROCEDURE update_language();


--
-- Name: language_dml_trig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER language_dml_trig INSTEAD OF INSERT OR DELETE OR UPDATE ON languages_view FOR EACH ROW EXECUTE PROCEDURE update_language_view();


--
-- Name: table_translation_edit_view; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER table_translation_edit_view INSTEAD OF INSERT OR DELETE OR UPDATE ON table_translation_edit_view FOR EACH ROW EXECUTE PROCEDURE update_table_translation_edit_view();


--
-- Name: fk_languages; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_language
    ADD CONSTRAINT fk_languages FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- Name: translations_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY translations
    ADD CONSTRAINT translations_language_id_fkey FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: add_keyring(character varying); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION add_keyring(p_hardware_id character varying) FROM PUBLIC;
REVOKE ALL ON FUNCTION add_keyring(p_hardware_id character varying) FROM postgres;
GRANT ALL ON FUNCTION add_keyring(p_hardware_id character varying) TO postgres;
GRANT ALL ON FUNCTION add_keyring(p_hardware_id character varying) TO PUBLIC;


--
-- Name: check_out_trigger(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION check_out_trigger() FROM PUBLIC;
REVOKE ALL ON FUNCTION check_out_trigger() FROM postgres;
GRANT ALL ON FUNCTION check_out_trigger() TO postgres;
GRANT ALL ON FUNCTION check_out_trigger() TO PUBLIC;


--
-- Name: checkin_checkout_time(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION checkin_checkout_time() FROM PUBLIC;
REVOKE ALL ON FUNCTION checkin_checkout_time() FROM postgres;
GRANT ALL ON FUNCTION checkin_checkout_time() TO postgres;
GRANT ALL ON FUNCTION checkin_checkout_time() TO PUBLIC;


--
-- Name: h_bigint(text); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION h_bigint(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION h_bigint(text) FROM postgres;
GRANT ALL ON FUNCTION h_bigint(text) TO postgres;
GRANT ALL ON FUNCTION h_bigint(text) TO PUBLIC;


--
-- Name: h_int(text); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION h_int(text) FROM PUBLIC;
REVOKE ALL ON FUNCTION h_int(text) FROM postgres;
GRANT ALL ON FUNCTION h_int(text) TO postgres;
GRANT ALL ON FUNCTION h_int(text) TO PUBLIC;


--
-- Name: process_audit(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION process_audit() FROM PUBLIC;
REVOKE ALL ON FUNCTION process_audit() FROM postgres;
GRANT ALL ON FUNCTION process_audit() TO postgres;
GRANT ALL ON FUNCTION process_audit() TO PUBLIC;


--
-- Name: rel_mapping_readout(regclass); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION rel_mapping_readout(tablename regclass) FROM PUBLIC;
REVOKE ALL ON FUNCTION rel_mapping_readout(tablename regclass) FROM postgres;
GRANT ALL ON FUNCTION rel_mapping_readout(tablename regclass) TO postgres;
GRANT ALL ON FUNCTION rel_mapping_readout(tablename regclass) TO PUBLIC;


--
-- Name: rel_mapping_readout(character varying, regclass); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION rel_mapping_readout(schema_name character varying, tablename regclass) FROM PUBLIC;
REVOKE ALL ON FUNCTION rel_mapping_readout(schema_name character varying, tablename regclass) FROM postgres;
GRANT ALL ON FUNCTION rel_mapping_readout(schema_name character varying, tablename regclass) TO postgres;
GRANT ALL ON FUNCTION rel_mapping_readout(schema_name character varying, tablename regclass) TO PUBLIC;


--
-- Name: remove_keyring(character varying); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION remove_keyring(p_hardware_id character varying) FROM PUBLIC;
REVOKE ALL ON FUNCTION remove_keyring(p_hardware_id character varying) FROM postgres;
GRANT ALL ON FUNCTION remove_keyring(p_hardware_id character varying) TO postgres;
GRANT ALL ON FUNCTION remove_keyring(p_hardware_id character varying) TO PUBLIC;


--
-- Name: totalrecords(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION totalrecords() FROM PUBLIC;
REVOKE ALL ON FUNCTION totalrecords() FROM postgres;
GRANT ALL ON FUNCTION totalrecords() TO postgres;
GRANT ALL ON FUNCTION totalrecords() TO PUBLIC;


--
-- Name: unknown2text(unknown); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION unknown2text(unknown) FROM PUBLIC;
REVOKE ALL ON FUNCTION unknown2text(unknown) FROM postgres;
GRANT ALL ON FUNCTION unknown2text(unknown) TO postgres;
GRANT ALL ON FUNCTION unknown2text(unknown) TO PUBLIC;


--
-- Name: update_einkaufszettel_todo(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_einkaufszettel_todo() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_einkaufszettel_todo() FROM postgres;
GRANT ALL ON FUNCTION update_einkaufszettel_todo() TO postgres;
GRANT ALL ON FUNCTION update_einkaufszettel_todo() TO PUBLIC;


--
-- Name: update_language(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_language() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_language() FROM postgres;
GRANT ALL ON FUNCTION update_language() TO postgres;
GRANT ALL ON FUNCTION update_language() TO PUBLIC;


--
-- Name: update_language_view(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_language_view() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_language_view() FROM postgres;
GRANT ALL ON FUNCTION update_language_view() TO postgres;
GRANT ALL ON FUNCTION update_language_view() TO PUBLIC;


--
-- Name: update_table_translation_edit_view(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_table_translation_edit_view() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_table_translation_edit_view() FROM postgres;
GRANT ALL ON FUNCTION update_table_translation_edit_view() TO postgres;
GRANT ALL ON FUNCTION update_table_translation_edit_view() TO PUBLIC;


--
-- Name: update_tableactions(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_tableactions() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_tableactions() FROM postgres;
GRANT ALL ON FUNCTION update_tableactions() TO postgres;
GRANT ALL ON FUNCTION update_tableactions() TO PUBLIC;


--
-- Name: update_worktimes(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_worktimes() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_worktimes() FROM postgres;
GRANT ALL ON FUNCTION update_worktimes() TO postgres;
GRANT ALL ON FUNCTION update_worktimes() TO PUBLIC;


--
-- Name: update_worktimes_fast(); Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON FUNCTION update_worktimes_fast() FROM PUBLIC;
REVOKE ALL ON FUNCTION update_worktimes_fast() FROM postgres;
GRANT ALL ON FUNCTION update_worktimes_fast() TO postgres;
GRANT ALL ON FUNCTION update_worktimes_fast() TO PUBLIC;


--
-- Name: menu; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE menu FROM PUBLIC;
REVOKE ALL ON TABLE menu FROM postgres;
GRANT ALL ON TABLE menu TO postgres;
GRANT SELECT ON TABLE menu TO generica_user;


--
-- Name: languages; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE languages FROM PUBLIC;
REVOKE ALL ON TABLE languages FROM postgres;
GRANT ALL ON TABLE languages TO postgres;
GRANT SELECT ON TABLE languages TO generica_user;


--
-- Name: user_language; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE user_language FROM PUBLIC;
REVOKE ALL ON TABLE user_language FROM postgres;
GRANT ALL ON TABLE user_language TO postgres;
GRANT SELECT ON TABLE user_language TO generica_user;


--
-- Name: current_language; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE current_language FROM PUBLIC;
REVOKE ALL ON TABLE current_language FROM postgres;
GRANT ALL ON TABLE current_language TO postgres;
GRANT SELECT ON TABLE current_language TO generica_user;


--
-- Name: formerrors_translations; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formerrors_translations FROM PUBLIC;
REVOKE ALL ON TABLE formerrors_translations FROM postgres;
GRANT ALL ON TABLE formerrors_translations TO postgres;
GRANT SELECT ON TABLE formerrors_translations TO generica_user;


--
-- Name: formerrors_translations_language; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formerrors_translations_language FROM PUBLIC;
REVOKE ALL ON TABLE formerrors_translations_language FROM postgres;
GRANT ALL ON TABLE formerrors_translations_language TO postgres;
GRANT SELECT ON TABLE formerrors_translations_language TO generica_user;


--
-- Name: tables; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE tables FROM PUBLIC;
REVOKE ALL ON TABLE tables FROM postgres;
GRANT ALL ON TABLE tables TO postgres;
GRANT SELECT ON TABLE tables TO generica_user;


--
-- Name: customization_elementorder; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE customization_elementorder FROM PUBLIC;
REVOKE ALL ON TABLE customization_elementorder FROM postgres;
GRANT ALL ON TABLE customization_elementorder TO postgres;
GRANT SELECT ON TABLE customization_elementorder TO generica_user;


--
-- Name: dummy_rel; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE dummy_rel FROM PUBLIC;
REVOKE ALL ON TABLE dummy_rel FROM postgres;
GRANT ALL ON TABLE dummy_rel TO postgres;
GRANT SELECT ON TABLE dummy_rel TO generica_user;


--
-- Name: formelement_edit_tables; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelement_edit_tables FROM PUBLIC;
REVOKE ALL ON TABLE formelement_edit_tables FROM postgres;
GRANT ALL ON TABLE formelement_edit_tables TO postgres;
GRANT SELECT ON TABLE formelement_edit_tables TO generica_user;


--
-- Name: formelements_order; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelements_order FROM PUBLIC;
REVOKE ALL ON TABLE formelements_order FROM postgres;
GRANT ALL ON TABLE formelements_order TO postgres;
GRANT SELECT ON TABLE formelements_order TO generica_user;


--
-- Name: translations; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE translations FROM PUBLIC;
REVOKE ALL ON TABLE translations FROM postgres;
GRANT ALL ON TABLE translations TO postgres;
GRANT SELECT ON TABLE translations TO generica_user;


--
-- Name: formelement_orders_and_translation; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelement_orders_and_translation FROM PUBLIC;
REVOKE ALL ON TABLE formelement_orders_and_translation FROM postgres;
GRANT ALL ON TABLE formelement_orders_and_translation TO postgres;
GRANT SELECT ON TABLE formelement_orders_and_translation TO generica_user;


--
-- Name: formelements_order_edit_view; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelements_order_edit_view FROM PUBLIC;
REVOKE ALL ON TABLE formelements_order_edit_view FROM postgres;
GRANT ALL ON TABLE formelements_order_edit_view TO postgres;
GRANT SELECT ON TABLE formelements_order_edit_view TO generica_user;


--
-- Name: formelements_order_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE formelements_order_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE formelements_order_id_seq FROM postgres;
GRANT ALL ON SEQUENCE formelements_order_id_seq TO postgres;
GRANT SELECT ON SEQUENCE formelements_order_id_seq TO generica_user;


--
-- Name: formerrors_translations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE formerrors_translations_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE formerrors_translations_id_seq FROM postgres;
GRANT ALL ON SEQUENCE formerrors_translations_id_seq TO postgres;
GRANT SELECT ON SEQUENCE formerrors_translations_id_seq TO generica_user;


--
-- Name: languages_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE languages_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE languages_id_seq FROM postgres;
GRANT ALL ON SEQUENCE languages_id_seq TO postgres;
GRANT SELECT ON SEQUENCE languages_id_seq TO generica_user;


--
-- Name: languages_view; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE languages_view FROM PUBLIC;
REVOKE ALL ON TABLE languages_view FROM postgres;
GRANT ALL ON TABLE languages_view TO postgres;
GRANT SELECT ON TABLE languages_view TO generica_user;


--
-- Name: menu_id2_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE menu_id2_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE menu_id2_seq FROM postgres;
GRANT ALL ON SEQUENCE menu_id2_seq TO postgres;
GRANT SELECT ON SEQUENCE menu_id2_seq TO generica_user;


--
-- Name: menu_menu_idmenu_rel_mapping; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE menu_menu_idmenu_rel_mapping FROM PUBLIC;
REVOKE ALL ON TABLE menu_menu_idmenu_rel_mapping FROM postgres;
GRANT ALL ON TABLE menu_menu_idmenu_rel_mapping TO postgres;
GRANT SELECT ON TABLE menu_menu_idmenu_rel_mapping TO generica_user;


--
-- Name: table_rights; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE table_rights FROM PUBLIC;
REVOKE ALL ON TABLE table_rights FROM postgres;
GRANT ALL ON TABLE table_rights TO postgres;
GRANT SELECT ON TABLE table_rights TO generica_user;


--
-- Name: menu_view; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE menu_view FROM PUBLIC;
REVOKE ALL ON TABLE menu_view FROM postgres;
GRANT ALL ON TABLE menu_view TO postgres;
GRANT SELECT ON TABLE menu_view TO generica_user;


--
-- Name: schema_and_translation; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE schema_and_translation FROM PUBLIC;
REVOKE ALL ON TABLE schema_and_translation FROM postgres;
GRANT ALL ON TABLE schema_and_translation TO postgres;
GRANT SELECT ON TABLE schema_and_translation TO generica_user;


--
-- Name: table_translation_edit_view; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE table_translation_edit_view FROM PUBLIC;
REVOKE ALL ON TABLE table_translation_edit_view FROM postgres;
GRANT ALL ON TABLE table_translation_edit_view TO postgres;
GRANT SELECT ON TABLE table_translation_edit_view TO generica_user;


--
-- Name: translations_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE translations_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE translations_id_seq FROM postgres;
GRANT ALL ON SEQUENCE translations_id_seq TO postgres;
GRANT SELECT ON SEQUENCE translations_id_seq TO generica_user;


--
-- Name: user_language_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE user_language_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE user_language_id_seq FROM postgres;
GRANT ALL ON SEQUENCE user_language_id_seq TO postgres;
GRANT SELECT ON SEQUENCE user_language_id_seq TO generica_user;


--
-- Name: view_menu; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE view_menu FROM PUBLIC;
REVOKE ALL ON TABLE view_menu FROM postgres;
GRANT ALL ON TABLE view_menu TO postgres;
GRANT SELECT ON TABLE view_menu TO generica_user;


--
-- Name: worktimes; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE worktimes FROM PUBLIC;
REVOKE ALL ON TABLE worktimes FROM postgres;
GRANT ALL ON TABLE worktimes TO postgres;
GRANT SELECT ON TABLE worktimes TO generica_user;


--
-- Name: worktimes_id_seq; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON SEQUENCE worktimes_id_seq FROM PUBLIC;
REVOKE ALL ON SEQUENCE worktimes_id_seq FROM postgres;
GRANT ALL ON SEQUENCE worktimes_id_seq TO postgres;
GRANT SELECT ON SEQUENCE worktimes_id_seq TO generica_user;


--
-- PostgreSQL database dump complete
--

