--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.translations DROP CONSTRAINT translations_language_id_fkey;
ALTER TABLE ONLY public.user_language DROP CONSTRAINT fk_languages;
DROP TRIGGER table_translation_edit_view ON public.table_translation_edit_view;
DROP TRIGGER language_dml_trig ON public.languages_view;
DROP TRIGGER current_language_dml_trig ON public.current_language;
DROP INDEX public.fki_languages;
SET search_path = test_schema, pg_catalog;

ALTER TABLE ONLY test_schema.test_table DROP CONSTRAINT test_table_pkey;
SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.user_language DROP CONSTRAINT user_language_pkey;
ALTER TABLE ONLY public.translations DROP CONSTRAINT translations_pkey;
ALTER TABLE ONLY public.menu DROP CONSTRAINT pk_menu;
ALTER TABLE ONLY public.formelements_order DROP CONSTRAINT pk_formelements_order;
ALTER TABLE ONLY public.languages DROP CONSTRAINT languages_pkey;
ALTER TABLE ONLY public.checkin_checkout DROP CONSTRAINT checkin_checkout_pkey;
SET search_path = test_schema, pg_catalog;

SET search_path = public, pg_catalog;

SET search_path = test_schema, pg_catalog;

ALTER TABLE test_schema.test_table ALTER COLUMN id DROP DEFAULT;
SET search_path = public, pg_catalog;

ALTER TABLE public.worktimes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.user_language ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.menu ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.languages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formerrors_translations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formelements_order ALTER COLUMN id DROP DEFAULT;
SET search_path = test_schema, pg_catalog;

DROP SEQUENCE test_schema.test_table_id_seq;
DROP TABLE test_schema.test_table;
SET search_path = public, pg_catalog;

DROP SEQUENCE public.worktimes_id_seq;
DROP TABLE public.worktimes;
DROP SEQUENCE public.user_language_id_seq;
DROP SEQUENCE public.translations_id_seq;
DROP VIEW public.table_translation_edit_view;
DROP VIEW public.table_rigths;
DROP VIEW public.schema_and_translation;
DROP VIEW public.menu_menu_idmenu_rel_mapping;
DROP SEQUENCE public.menu_id2_seq;
DROP TABLE public.menu;
DROP VIEW public.languages_view;
DROP SEQUENCE public.languages_id_seq;
DROP SEQUENCE public.formerrors_translations_id_seq;
DROP SEQUENCE public.formelements_order_id_seq;
DROP VIEW public.formelements_order_edit_view;
DROP VIEW public.formelement_orders_and_translation;
DROP TABLE public.translations;
DROP TABLE public.formelements_order;
DROP VIEW public.formelement_edit_tables;
DROP VIEW public.dummy_rel;
DROP VIEW public.customization_elementorder;
DROP VIEW public.tables;
DROP TABLE public.checkin_checkout;
DROP VIEW public.check_constraints;
DROP VIEW public.formerrors_translations_language;
DROP TABLE public.formerrors_translations;
DROP VIEW public.current_language;
DROP TABLE public.user_language;
DROP TABLE public.languages;
DROP FUNCTION public.update_worktimes_fast();
DROP FUNCTION public.update_worktimes();
DROP FUNCTION public.update_tableactions();
DROP FUNCTION public.update_table_translation_edit_view();
DROP FUNCTION public.update_language_view();
DROP FUNCTION public.update_language();
DROP FUNCTION public.update_einkaufszettel_todo();
DROP FUNCTION public.unknown2text(unknown);
DROP FUNCTION public.totalrecords();
DROP FUNCTION public.rel_mapping_readout(tablename regclass);
DROP FUNCTION public.process_audit();
DROP FUNCTION public.h_int(text);
DROP FUNCTION public.h_bigint(text);
DROP FUNCTION public.checkin_checkout_time();
DROP FUNCTION public.check_out_trigger();
DROP EXTENSION plpgsql;
DROP SCHEMA test_schema;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: test_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA test_schema;


ALTER SCHEMA test_schema OWNER TO postgres;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: check_out_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION check_out_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare
	totalCheckIns integer;
	timeOfCheckIn timestamp;
   BEGIN
	select count(*) into totalCheckIns from checkin_checkout where user = current_user;
	if totalCheckIns <= 0 THEN
		INSERT INTO checkin_checkout("user", time_of_checkin) VALUES(CURRENT_USER,CURRENT_TIMESTAMP);
		return NEW;
	ELSE 
		select time_of_checkin into timeOfCheckIn from checkin_checkout where user = current_user;
		delete from checkin_checkout where user = current_user;
		INSERT INTO worktimes (date_start, date_end, description) values(timeOfCheckIn, current_timestamp, NEW.description);
		return NEW;
	END IF;
    END;
$$;


ALTER FUNCTION public.check_out_trigger() OWNER TO postgres;

--
-- Name: checkin_checkout_time(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION checkin_checkout_time() RETURNS character varying
    LANGUAGE plpgsql
    AS $$
declare
	totalCheckIns integer;
	timeOfCheckIn timestamp;
BEGIN
	select count(*) into totalCheckIns from checkin_checkout where user = current_user;
	if totalCheckIns <= 0 THEN
		INSERT INTO checkin_checkout("user", time_of_checkin) VALUES(CURRENT_USER,CURRENT_TIMESTAMP);
		return 'Checked In';
	ELSE 
		select time_of_checkin into timeOfCheckIn from checkin_checkout where user = current_user;
		delete from checkin_checkout where user = current_user;
		INSERT INTO worktimes (date_start, date_end) values(timeOfCheckIn, current_timestamp);
		return 'Checked out';
	END IF;
	END;
$$;


ALTER FUNCTION public.checkin_checkout_time() OWNER TO postgres;

--
-- Name: h_bigint(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION h_bigint(text) RETURNS bigint
    LANGUAGE sql
    AS $_$
 select ('x'||substr(md5($1),1,16))::bit(64)::bigint;
$_$;


ALTER FUNCTION public.h_bigint(text) OWNER TO postgres;

--
-- Name: h_int(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION h_int(text) RETURNS integer
    LANGUAGE sql
    AS $_$
 select ('x'||substr(md5($1),1,8))::bit(32)::int;
$_$;


ALTER FUNCTION public.h_int(text) OWNER TO postgres;

--
-- Name: process_audit(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION process_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
    BEGIN
        --
        -- Create a row in emp_audit to reflect the operation performed on emp,
        -- make use of the special variable TG_OP to work out the operation.
        --
        IF (TG_OP = 'DELETE') THEN
            EXECUTE format('INSERT INTO %I SELECT  CURRENT_TIMESTAMP,''D'', ($1).*', TG_TABLE_NAME || '_archive')
            USING OLD;
RETURN OLD;
        ELSIF (TG_OP = 'UPDATE') THEN
             EXECUTE format('INSERT INTO %I SELECT  CURRENT_TIMESTAMP,''U'', ($1).*', TG_TABLE_NAME || '_archive')
             USING OLD;
            RETURN NEW;
        ELSIF (TG_OP = 'INSERT') THEN
	
            RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$_$;


ALTER FUNCTION public.process_audit() OWNER TO postgres;

--
-- Name: rel_mapping_readout(regclass); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION rel_mapping_readout(tablename regclass) RETURNS TABLE(id integer, value integer, label character varying)
    LANGUAGE plpgsql
    AS $$
BEGIN
RETURN QUERY EXECUTE format('SELECT id, value, label FROM %s ', tableName);
END
$$;


ALTER FUNCTION public.rel_mapping_readout(tablename regclass) OWNER TO postgres;

--
-- Name: totalrecords(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION totalrecords() RETURNS integer
    LANGUAGE plpgsql
    AS $$
declare
	total integer;
BEGIN
   SELECT count(*) into total FROM COMPANY;
   RETURN total;
END;
$$;


ALTER FUNCTION public.totalrecords() OWNER TO postgres;

--
-- Name: unknown2text(unknown); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION unknown2text(unknown) RETURNS text
    LANGUAGE plpgsql
    AS $_$ begin return text($1::char); end $_$;


ALTER FUNCTION public.unknown2text(unknown) OWNER TO postgres;

--
-- Name: update_einkaufszettel_todo(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_einkaufszettel_todo() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
 IF TG_OP = 'INSERT' THEN
       
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
    
       RETURN NEW;
	ELSIF TG_OP = 'DELETE' THEN
	update einkaufszettel set eingekauft = true where id=OLD.id;
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_einkaufszettel_todo() OWNER TO postgres;

--
-- Name: update_language(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_language() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' OR  TG_OP = 'UPDATE' THEN
	update user_language ul set language_id = 
		(select id from languages l where l.language_name = NEW.language_name)
	where ul.username = current_user;
        insert into user_language (username, language_id)
	select current_user, (select id from languages l where l.language_name = NEW.language_name)	
        where NOT EXISTS(
		select 1 from user_language where username = current_user
        );
        RETURN NEW;
    
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_language() OWNER TO postgres;

--
-- Name: update_language_view(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_language_view() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
	insert into languages(language_name) values 
	(NEW.language_name);
        RETURN NEW;
	elseif TG_OP = 'UPDATE' THEN
	update languages set language_name = NEW.language_name where id = NEW.language_id;
	elseif TG_OP = 'DELETE' THEN
	delete from languages where id=NEW.language_id;
	RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_language_view() OWNER TO postgres;

--
-- Name: update_table_translation_edit_view(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_table_translation_edit_view() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
       update translations tr set translation = NEW.translation 
       where EXISTS (
	select table_name from formelements_order feo 
	inner join languages l ON l.id= tr.language_id AND l.language_name = (select language_name from current_language)
	where feo.id=NEW.id 
	 and tr.table_name=feo.table_name
	 and tr.column_name=feo.column_name
	
	);
	
	INSERT INTO translations 
	      (table_name,column_name, translation, language_id) 
	select
	 table_name,column_name, NEW.translation, l.id 
	 from formelements_order feo
	inner join current_language cr ON 1=1
	inner join languages l ON cr.language_name = l.language_name
	where NOT EXISTS(
	select * from translations trInner 
	inner join languages l ON l.id= trInner.language_id AND l.language_name = (select language_name from current_language)
	where feo.table_name = trInner.table_name and feo.column_name = trInner.column_name
	 
	) and feo.id = NEW.id;
       RETURN NEW;
      ELSIF TG_OP = 'DELETE' THEN
       
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_table_translation_edit_view() OWNER TO postgres;

--
-- Name: update_tableactions(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_tableactions() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
        --
        -- Create a row in emp_audit to reflect the operation performed on emp,
        -- make use of the special variable TG_OP to work out the operation.
        --
        IF (TG_OP = 'DELETE') THEN
            delete from table_actions_inner where id = OLD.id;
	    RETURN OLD;
        ELSIF (TG_OP = 'UPDATE') THEN
	    delete from table_actions_inner where id = OLD.id;
	    insert into table_actions_inner select NEW.*;
            RETURN NEW;
        ELSIF (TG_OP = 'INSERT') THEN
        
	    insert into table_actions_inner (
            link, table_name, label_action, is_action)
		VALUES (new.link, new.table_name, new.label_action, new.is_action);
            RETURN NEW;
        END IF;
        RETURN NULL; -- result is ignored since this is an AFTER trigger
    END;
$$;


ALTER FUNCTION public.update_tableactions() OWNER TO postgres;

--
-- Name: update_worktimes(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_worktimes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        INSERT INTO worktimes (date_start, date_end)  VALUES(NEW.date_start,NEW.date_end);
        RETURN NEW;
      ELSIF TG_OP = 'UPDATE' THEN
       UPDATE worktimes SET date_start=NEW.date_start, date_end=NEW.date_end 
       WHERE id=OLD.id;
       RETURN NEW;
      ELSIF TG_OP = 'DELETE' THEN
       DELETE FROM worktimes WHERE id=OLD.id;
       RETURN NULL;
      END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_worktimes() OWNER TO postgres;

--
-- Name: update_worktimes_fast(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION update_worktimes_fast() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
   BEGIN
      IF TG_OP = 'INSERT' THEN
        INSERT INTO worktimes_persist (date_start, date_end)  VALUES(NEW.date_start,NEW.date_end);
        RETURN NEW;
        END IF;
      RETURN NEW;
    END;
$$;


ALTER FUNCTION public.update_worktimes_fast() OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE languages (
    id integer NOT NULL,
    language_name character varying NOT NULL
);


ALTER TABLE public.languages OWNER TO postgres;

--
-- Name: user_language; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE user_language (
    id integer NOT NULL,
    language_id integer NOT NULL,
    username character varying NOT NULL
);


ALTER TABLE public.user_language OWNER TO postgres;

--
-- Name: current_language; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW current_language AS
    SELECT languages.language_name FROM (user_language JOIN languages ON ((languages.id = user_language.language_id))) WHERE ((user_language.username)::name = "current_user"()) UNION SELECT 'english'::character varying AS language_name FROM pg_user pgu WHERE ((NOT (EXISTS (SELECT 1 FROM user_language ul WHERE (pgu.usename = (ul.username)::name)))) AND (pgu.usename = "current_user"()));


ALTER TABLE public.current_language OWNER TO postgres;

--
-- Name: formerrors_translations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE formerrors_translations (
    id integer NOT NULL,
    check_constraints_id bigint NOT NULL,
    error_msg character varying(1024) NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE public.formerrors_translations OWNER TO postgres;

--
-- Name: formerrors_translations_language; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formerrors_translations_language AS
    SELECT fet.id, fet.check_constraints_id, fet.error_msg, fet.language_id FROM ((formerrors_translations fet JOIN languages l ON ((l.id = fet.language_id))) JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (fet.language_id = l.id))));


ALTER TABLE public.formerrors_translations_language OWNER TO postgres;

--
-- Name: check_constraints; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW check_constraints AS
    SELECT cc.id, CASE ((cc.view_schema)::text = 'public'::text) WHEN true THEN (cc.table_name)::text ELSE (((cc.view_schema)::text || '.'::text) || (cc.table_name)::text) END AS table_name, cc.column_name, cc.check_clause, COALESCE(fetl.error_msg, (((cc.column_name)::text || ' is wrong'::text))::character varying) AS error_msg FROM ((WITH RECURSIVE resolve_view_hierarchy(view_name, table_name) AS (SELECT view_table_usage.view_name, view_table_usage.table_name, view_table_usage.view_schema FROM information_schema.view_table_usage UNION ALL SELECT parent.view_name, sub_view.table_name, sub_view.view_schema FROM information_schema.view_table_usage sub_view, information_schema.view_table_usage parent WHERE ((sub_view.view_name)::text = (parent.table_name)::text)) SELECT h_bigint((((rvc.view_name)::text || (tc.column_name)::text) || (cc.check_clause)::text)) AS id, rvc.view_name AS table_name, tc.column_name, cc.check_clause, rvc.view_schema FROM ((resolve_view_hierarchy rvc JOIN information_schema.constraint_column_usage tc ON (((tc.table_name)::text = (rvc.table_name)::text))) JOIN information_schema.check_constraints cc ON ((((cc.constraint_name)::text = (tc.constraint_name)::text) AND (NOT (EXISTS (SELECT 1 FROM information_schema.views v WHERE ((v.table_name)::text = (rvc.table_name)::text))))))) UNION ALL SELECT h_bigint((((cu.table_name)::text || (cu.column_name)::text) || (cc.check_clause)::text)) AS id, cu.table_name, cu.column_name, cc.check_clause, cu.table_schema AS view_schema FROM (information_schema.constraint_column_usage cu JOIN information_schema.check_constraints cc ON (((cc.constraint_name)::text = (cu.constraint_name)::text)))) cc LEFT JOIN formerrors_translations_language fetl ON ((fetl.check_constraints_id = cc.id)));


ALTER TABLE public.check_constraints OWNER TO postgres;

--
-- Name: checkin_checkout; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE checkin_checkout (
    "user" character varying(65) NOT NULL,
    time_of_checkin timestamp without time zone NOT NULL
);


ALTER TABLE public.checkin_checkout OWNER TO postgres;

--
-- Name: tables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW tables AS
    SELECT tables.table_catalog, tables.table_name, tables.table_schema FROM information_schema.tables WHERE ((tables.table_catalog)::name = current_database());


ALTER TABLE public.tables OWNER TO postgres;

--
-- Name: customization_elementorder; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW customization_elementorder AS
    SELECT tables.table_name AS id FROM tables UNION SELECT '1'::character varying AS id;


ALTER TABLE public.customization_elementorder OWNER TO postgres;

--
-- Name: dummy_rel; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW dummy_rel AS
    SELECT 1 AS id, 1 AS value, 'dummy'::character varying AS label WHERE (1 <> 1);


ALTER TABLE public.dummy_rel OWNER TO postgres;

--
-- Name: formelement_edit_tables; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelement_edit_tables AS
    SELECT CASE ((t.table_schema)::text = 'public'::text) WHEN true THEN (t.table_name)::text ELSE (((t.table_schema)::text || '.'::text) || (t.table_name)::text) END AS id FROM information_schema.tables t;


ALTER TABLE public.formelement_edit_tables OWNER TO postgres;

--
-- Name: formelements_order; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE formelements_order (
    id integer NOT NULL,
    column_name character varying(65),
    table_name character varying(65),
    schema_name character varying(65)
);


ALTER TABLE public.formelements_order OWNER TO postgres;

--
-- Name: translations; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE translations (
    id integer NOT NULL,
    table_name character(65) NOT NULL,
    column_name character varying NOT NULL,
    translation character varying NOT NULL,
    language_id integer NOT NULL
);


ALTER TABLE public.translations OWNER TO postgres;

--
-- Name: formelement_orders_and_translation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelement_orders_and_translation AS
    SELECT feo.id, feo.column_name, feo.table_name, COALESCE(t.translation, feo.column_name) AS translation, feo.schema_name FROM (formelements_order feo LEFT JOIN translations t ON (((((feo.table_name)::bpchar = t.table_name) AND ((feo.column_name)::text = (t.column_name)::text)) AND (EXISTS (SELECT 1 FROM (languages l JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (t.language_id = l.id)))))))));


ALTER TABLE public.formelement_orders_and_translation OWNER TO postgres;

--
-- Name: formelements_order_edit_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW formelements_order_edit_view AS
    SELECT (((c.table_schema)::text || '.'::text) || (c.table_name)::text) AS id, c.column_name, c.table_name, c.table_schema FROM (information_schema.columns c LEFT JOIN formelements_order feo ON (((((c.table_name)::text = (feo.table_name)::text) AND ((feo.column_name)::text = (c.column_name)::text)) AND ((c.table_catalog)::name = current_database())))) ORDER BY feo.id, c.table_name;


ALTER TABLE public.formelements_order_edit_view OWNER TO postgres;

--
-- Name: formelements_order_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formelements_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formelements_order_id_seq OWNER TO postgres;

--
-- Name: formelements_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formelements_order_id_seq OWNED BY formelements_order.id;


--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formerrors_translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.formerrors_translations_id_seq OWNER TO postgres;

--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formerrors_translations_id_seq OWNED BY formerrors_translations.id;


--
-- Name: languages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE languages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.languages_id_seq OWNER TO postgres;

--
-- Name: languages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE languages_id_seq OWNED BY languages.id;


--
-- Name: languages_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW languages_view AS
    SELECT languages.id, languages.language_name FROM languages;


ALTER TABLE public.languages_view OWNER TO postgres;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE menu (
    link character varying(120),
    menulabel character varying(45),
    menu_idmenu integer,
    id integer NOT NULL
);


ALTER TABLE public.menu OWNER TO postgres;

--
-- Name: menu_id2_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE menu_id2_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.menu_id2_seq OWNER TO postgres;

--
-- Name: menu_id2_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE menu_id2_seq OWNED BY menu.id;


--
-- Name: menu_menu_idmenu_rel_mapping; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW menu_menu_idmenu_rel_mapping AS
    SELECT menu.id, menu.id AS value, menu.menulabel AS label FROM menu UNION SELECT 1 AS id, 1 AS value, 'abc'::character varying AS label;


ALTER TABLE public.menu_menu_idmenu_rel_mapping OWNER TO postgres;

--
-- Name: schema_and_translation; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW schema_and_translation AS
    SELECT CASE ((c.table_schema)::text = 'public'::text) WHEN true THEN (c.table_name)::text ELSE (((c.table_schema)::text || '.'::text) || (c.table_name)::text) END AS table_name, c.column_name AS field, c.character_maximum_length AS textlength, COALESCE(((SELECT c.data_type WHERE (mappings.table_name IS NULL)))::character varying, 'combobox'::character varying) AS data_type, (SELECT string_agg((rel_mapping_readout.value)::text, ','::text) AS string_agg FROM rel_mapping_readout((COALESCE((mappings.table_name)::character varying, 'dummy_rel'::character varying))::regclass) rel_mapping_readout(id, value, label)) AS valuescombobox, (SELECT string_agg((rel_mapping_readout.label)::text, ','::text) AS string_agg FROM rel_mapping_readout((COALESCE((mappings.table_name)::character varying, 'dummy_rel'::character varying))::regclass) rel_mapping_readout(id, value, label)) AS labels, COALESCE(trl.translation, (c.column_name)::character varying) AS "displayName", true AS visible FROM ((((tables t JOIN information_schema.columns c ON (((((t.table_name)::text = (c.table_name)::text) AND ((c.table_catalog)::name = current_database())) AND ((c.table_schema)::text = (t.table_schema)::text)))) LEFT JOIN formelements_order feo ON (((((feo.table_name)::text = (t.table_name)::text) AND ((feo.column_name)::text = (c.column_name)::text)) AND ((c.table_schema)::text = (feo.schema_name)::text)))) LEFT JOIN tables mappings ON (((mappings.table_name)::text = ((((t.table_name)::text || '_'::text) || (c.column_name)::text) || '_rel_mapping'::text)))) LEFT JOIN translations trl ON ((((trl.table_name = (t.table_name)::bpchar) AND ((trl.column_name)::text = (c.column_name)::text)) AND (EXISTS (SELECT 1 FROM user_language WHERE (((user_language.username)::name = "current_user"()) AND (trl.language_id = user_language.language_id))))))) ORDER BY t.table_name, feo.id;


ALTER TABLE public.schema_and_translation OWNER TO postgres;

--
-- Name: table_rigths; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW table_rigths AS
    SELECT CASE (pg_namespace.nspname = 'public'::name) WHEN true THEN (pg_class.relname)::text ELSE (((pg_namespace.nspname)::text || '.'::text) || (pg_class.relname)::text) END AS table_name, CASE pg_class.relkind WHEN 'r'::"char" THEN 'TABLE'::text WHEN 'v'::"char" THEN 'VIEW'::text ELSE NULL::text END AS relation_type, privs.priv FROM (pg_class JOIN pg_namespace ON ((pg_namespace.oid = pg_class.relnamespace))), pg_user, (VALUES ('SELECT'::text,1), ('INSERT'::text,2), ('UPDATE'::text,3), ('DELETE'::text,4)) privs(priv, privorder) WHERE ((((pg_class.relkind = ANY (ARRAY['r'::"char", 'v'::"char"])) AND has_table_privilege(pg_user.usesysid, pg_class.oid, privs.priv)) AND (NOT ((pg_namespace.nspname ~ '^pg_'::text) OR (pg_namespace.nspname = 'information_schema'::name)))) AND ("current_user"() = "current_user"()));


ALTER TABLE public.table_rigths OWNER TO postgres;

--
-- Name: table_translation_edit_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW table_translation_edit_view AS
    SELECT feo.id, COALESCE(t.translation, feo.column_name) AS translation FROM (formelements_order feo LEFT JOIN translations t ON (((((feo.table_name)::bpchar = t.table_name) AND ((feo.column_name)::text = (t.column_name)::text)) AND (EXISTS (SELECT 1 FROM (languages l JOIN current_language crl ON ((((l.language_name)::text = (crl.language_name)::text) AND (t.language_id = l.id)))))))));


ALTER TABLE public.table_translation_edit_view OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE translations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.translations_id_seq OWNER TO postgres;

--
-- Name: translations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE translations_id_seq OWNED BY translations.id;


--
-- Name: user_language_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE user_language_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_language_id_seq OWNER TO postgres;

--
-- Name: user_language_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE user_language_id_seq OWNED BY user_language.id;


--
-- Name: worktimes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE worktimes (
    id integer NOT NULL,
    "user" character varying(65) DEFAULT "current_user"() NOT NULL,
    date_start timestamp without time zone NOT NULL,
    date_end timestamp without time zone NOT NULL,
    description character varying DEFAULT ''::character varying NOT NULL,
    CONSTRAINT worktimes_check CHECK ((date_end > date_start))
);


ALTER TABLE public.worktimes OWNER TO postgres;

--
-- Name: worktimes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE worktimes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.worktimes_id_seq OWNER TO postgres;

--
-- Name: worktimes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE worktimes_id_seq OWNED BY worktimes.id;


SET search_path = test_schema, pg_catalog;

--
-- Name: test_table; Type: TABLE; Schema: test_schema; Owner: postgres; Tablespace: 
--

CREATE TABLE test_table (
    id integer NOT NULL,
    test character varying
);


ALTER TABLE test_schema.test_table OWNER TO postgres;

--
-- Name: test_table_id_seq; Type: SEQUENCE; Schema: test_schema; Owner: postgres
--

CREATE SEQUENCE test_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE test_schema.test_table_id_seq OWNER TO postgres;

--
-- Name: test_table_id_seq; Type: SEQUENCE OWNED BY; Schema: test_schema; Owner: postgres
--

ALTER SEQUENCE test_table_id_seq OWNED BY test_table.id;


SET search_path = public, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formelements_order ALTER COLUMN id SET DEFAULT (nextval('formelements_order_id_seq'::regclass) + 1);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formerrors_translations ALTER COLUMN id SET DEFAULT nextval('formerrors_translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY languages ALTER COLUMN id SET DEFAULT nextval('languages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY menu ALTER COLUMN id SET DEFAULT (nextval('menu_id2_seq'::regclass) + 17);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY translations ALTER COLUMN id SET DEFAULT nextval('translations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_language ALTER COLUMN id SET DEFAULT nextval('user_language_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY worktimes ALTER COLUMN id SET DEFAULT nextval('worktimes_id_seq'::regclass);


SET search_path = test_schema, pg_catalog;

--
-- Name: id; Type: DEFAULT; Schema: test_schema; Owner: postgres
--

ALTER TABLE ONLY test_table ALTER COLUMN id SET DEFAULT nextval('test_table_id_seq'::regclass);


SET search_path = public, pg_catalog;

--
-- Data for Name: checkin_checkout; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY checkin_checkout ("user", time_of_checkin) FROM stdin;
\.
COPY checkin_checkout ("user", time_of_checkin) FROM '$$PATH$$/2061.dat';

--
-- Data for Name: formelements_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formelements_order (id, column_name, table_name, schema_name) FROM stdin;
\.
COPY formelements_order (id, column_name, table_name, schema_name) FROM '$$PATH$$/2062.dat';

--
-- Name: formelements_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formelements_order_id_seq', 82, true);


--
-- Data for Name: formerrors_translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formerrors_translations (id, check_constraints_id, error_msg, language_id) FROM stdin;
\.
COPY formerrors_translations (id, check_constraints_id, error_msg, language_id) FROM '$$PATH$$/2060.dat';

--
-- Name: formerrors_translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formerrors_translations_id_seq', 2, true);


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY languages (id, language_name) FROM stdin;
\.
COPY languages (id, language_name) FROM '$$PATH$$/2058.dat';

--
-- Name: languages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('languages_id_seq', 4, true);


--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY menu (link, menulabel, menu_idmenu, id) FROM stdin;
\.
COPY menu (link, menulabel, menu_idmenu, id) FROM '$$PATH$$/2067.dat';

--
-- Name: menu_id2_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('menu_id2_seq', 27, true);


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY translations (id, table_name, column_name, translation, language_id) FROM stdin;
\.
COPY translations (id, table_name, column_name, translation, language_id) FROM '$$PATH$$/2063.dat';

--
-- Name: translations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('translations_id_seq', 50, true);


--
-- Data for Name: user_language; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY user_language (id, language_id, username) FROM stdin;
\.
COPY user_language (id, language_id, username) FROM '$$PATH$$/2059.dat';

--
-- Name: user_language_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('user_language_id_seq', 6, true);


--
-- Data for Name: worktimes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY worktimes (id, "user", date_start, date_end, description) FROM stdin;
\.
COPY worktimes (id, "user", date_start, date_end, description) FROM '$$PATH$$/2071.dat';

--
-- Name: worktimes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('worktimes_id_seq', 4220214, true);


SET search_path = test_schema, pg_catalog;

--
-- Data for Name: test_table; Type: TABLE DATA; Schema: test_schema; Owner: postgres
--

COPY test_table (id, test) FROM stdin;
\.
COPY test_table (id, test) FROM '$$PATH$$/2074.dat';

--
-- Name: test_table_id_seq; Type: SEQUENCE SET; Schema: test_schema; Owner: postgres
--

SELECT pg_catalog.setval('test_table_id_seq', 10, true);


SET search_path = public, pg_catalog;

--
-- Name: checkin_checkout_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY checkin_checkout
    ADD CONSTRAINT checkin_checkout_pkey PRIMARY KEY ("user", time_of_checkin);


--
-- Name: languages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (id);


--
-- Name: pk_formelements_order; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY formelements_order
    ADD CONSTRAINT pk_formelements_order PRIMARY KEY (id);


--
-- Name: pk_menu; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT pk_menu PRIMARY KEY (id);


--
-- Name: translations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (id);


--
-- Name: user_language_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY user_language
    ADD CONSTRAINT user_language_pkey PRIMARY KEY (id);


SET search_path = test_schema, pg_catalog;

--
-- Name: test_table_pkey; Type: CONSTRAINT; Schema: test_schema; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY test_table
    ADD CONSTRAINT test_table_pkey PRIMARY KEY (id);


SET search_path = public, pg_catalog;

--
-- Name: fki_languages; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX fki_languages ON user_language USING btree (language_id);


--
-- Name: current_language_dml_trig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER current_language_dml_trig INSTEAD OF INSERT OR DELETE OR UPDATE ON current_language FOR EACH ROW EXECUTE PROCEDURE update_language();


--
-- Name: language_dml_trig; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER language_dml_trig INSTEAD OF INSERT OR DELETE OR UPDATE ON languages_view FOR EACH ROW EXECUTE PROCEDURE update_language_view();


--
-- Name: table_translation_edit_view; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER table_translation_edit_view INSTEAD OF INSERT OR DELETE OR UPDATE ON table_translation_edit_view FOR EACH ROW EXECUTE PROCEDURE update_table_translation_edit_view();


--
-- Name: fk_languages; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY user_language
    ADD CONSTRAINT fk_languages FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- Name: translations_language_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY translations
    ADD CONSTRAINT translations_language_id_fkey FOREIGN KEY (language_id) REFERENCES languages(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: check_constraints; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE check_constraints FROM PUBLIC;
REVOKE ALL ON TABLE check_constraints FROM postgres;
GRANT ALL ON TABLE check_constraints TO postgres;
GRANT ALL ON TABLE check_constraints TO generica_admin;


--
-- Name: dummy_rel; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE dummy_rel FROM PUBLIC;
REVOKE ALL ON TABLE dummy_rel FROM postgres;
GRANT ALL ON TABLE dummy_rel TO postgres;
GRANT ALL ON TABLE dummy_rel TO generica_admin;


--
-- Name: formelement_edit_tables; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelement_edit_tables FROM PUBLIC;
REVOKE ALL ON TABLE formelement_edit_tables FROM postgres;
GRANT ALL ON TABLE formelement_edit_tables TO postgres;
GRANT ALL ON TABLE formelement_edit_tables TO generica_admin;


--
-- Name: formelements_order; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelements_order FROM PUBLIC;
REVOKE ALL ON TABLE formelements_order FROM postgres;
GRANT ALL ON TABLE formelements_order TO postgres;


--
-- Name: formelements_order_edit_view; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE formelements_order_edit_view FROM PUBLIC;
REVOKE ALL ON TABLE formelements_order_edit_view FROM postgres;
GRANT ALL ON TABLE formelements_order_edit_view TO postgres;
GRANT ALL ON TABLE formelements_order_edit_view TO generica_admin;


--
-- Name: schema_and_translation; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE schema_and_translation FROM PUBLIC;
REVOKE ALL ON TABLE schema_and_translation FROM postgres;
GRANT ALL ON TABLE schema_and_translation TO postgres;
GRANT ALL ON TABLE schema_and_translation TO generica_admin;


--
-- Name: table_rigths; Type: ACL; Schema: public; Owner: postgres
--

REVOKE ALL ON TABLE table_rigths FROM PUBLIC;
REVOKE ALL ON TABLE table_rigths FROM postgres;
GRANT ALL ON TABLE table_rigths TO postgres;
GRANT ALL ON TABLE table_rigths TO generica_admin;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public REVOKE ALL ON TABLES  FROM postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES  TO generica_admin;


--
-- PostgreSQL database dump complete
--

